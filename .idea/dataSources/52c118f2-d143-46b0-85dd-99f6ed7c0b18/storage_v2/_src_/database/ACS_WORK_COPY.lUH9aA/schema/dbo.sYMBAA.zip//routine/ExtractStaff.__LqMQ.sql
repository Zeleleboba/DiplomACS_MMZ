create procedure ExtractStaff @parametr_index int, @department_id int, @area_id int, @profession_code int, @start_date date, @close_date date
as
begin
set nocount on

	select Department_Id, Department_Name, Area_Id, Area_Name, Profession_Code, Profession_Name, Calculation_Date, Working_Time, Start_Working_Time, Required_Time, ROW_NUMBER() over(partition by Department_Id, Area_Id, Profession_Code order by Department_Id, Area_Id, Profession_Code, Calculation_Date) as ri1
	into #WorkingTable
	from StaffCalculation
	where Department_Id = @department_id and Area_Id = @area_id and Profession_Code = @profession_code and Parametr_Index = @parametr_index and Calculation_Date between @start_date and @close_date
	
	select distinct Calculation_Date, ROW_NUMBER() over(order by Calculation_Date) as Id
	into #Months
	from #WorkingTable


	declare @index_i int = 1, @index_max int = (select count(id) from #Months), @str_reqt varchar(max) = '', @str_workt varchar(max), @str_sworkt varchar(max), @str_index varchar(max) = '', @str_head varchar(max) = '',
	@query nvarchar(max) = ''

	while @index_i <= @index_max 
	begin
		set @str_reqt = concat(@str_reqt,'sum([',@index_i,']) as RQT',@index_i,', ')
		set @str_sworkt = concat(@str_workt,'sum([',@index_i,']) as SWT',@index_i,', ')
		set @str_workt = concat(@str_sworkt,'sum([',@index_i,']) as WT',@index_i,', ')
		--set @str_head = concat(@str_head,'sum([',@index_i,']) as SWT',@index_i,', sum([',@index_i,']) as WT',@index_i,', sum([',@index_i,']) as RQT',@index_i,',')
		set @str_head = concat(@str_head,' b.SWT',@index_i,', c.WT',@index_i,', a.RQT',@index_i,',')
	
		set @str_index = concat(@str_index, '[',@index_i,'],')
	set @index_i +=1
	end;
	set @str_reqt = SUBSTRING(@str_reqt, 1, len(@str_reqt)-1)
	set @str_workt = SUBSTRING(@str_workt, 1, len(@str_workt)-1)
	set @str_sworkt = SUBSTRING(@str_sworkt, 1, len(@str_sworkt)-1)
	set @str_head = SUBSTRING(@str_head, 1, len(@str_head)-1)
	set @str_index = substring(@str_index,1,len(@str_index)-1) 


	set @query = concat('select a.Department_Id, a.Area_Id, a.Profession_Code,',@str_head,char(10),
						'from (select Department_Id, Area_Id, Profession_Code, ', @str_reqt,char(10),
								'from  #WorkingTable as a pivot (sum(Required_Time) for ri1 in (', @str_index,')) as pvt', char(10),
								'group by  Department_Id, Area_Id, Profession_Code) as a', char(10),
						'join (select Department_Id, Area_Id, Profession_Code, ', @str_sworkt,char(10),
								'from  #WorkingTable as a pivot (sum(Start_Working_Time) for ri1 in (', @str_index,')) as pvt', char(10),
								'group by  Department_Id, Area_Id, Profession_Code) as b on a.area_id = b.area_id and a.profession_code= b.profession_code', char(10),
						'join (select Department_Id, Area_Id, Profession_Code, ', @str_workt,char(10),
								'from  #WorkingTable as a pivot (sum(Start_Working_Time) for ri1 in (', @str_index,')) as pvt', char(10),
								'group by  Department_Id, Area_Id, Profession_Code) as c on a.area_id = c.area_id and a.profession_code= c.profession_code', char(10))

	exec sp_executesql @Query
end;
go

