CREATE procedure [CalculateWorkers] 
@department int = 0,
@area int = 0,
@profession int = 0,
@OpenDate date,
@CloseDate date,
@param_overtime int = 0,
@param_work_sat int = 0,
@param_area_move int = 0,
@param_department_move int = 0,
@param_replace int = 0
as
set nocount on
begin
	drop table CalculationInformation

	select a.Worker_Section_ID, a.Worker_Profession_ID, count(a.Worker_ID) as Count_Workers, d.FirstDay, d.Fifth_Week_Days, d.Sixth_Week_Days, count(a.Worker_ID)*8.0*d.Fifth_Week_Days as StartWorkingTime
	into #Fond_WT
	from Workers a
	join Professions b on a.Worker_Profession_ID = b.Profession_Id
	join Departments_Sections c on a.Worker_Section_ID = c.Department_Id
	join WorkingDaysInMonth d on d.Fifth_Week_Days <> 0
	group by a.Worker_Section_ID, c.Department_Name,a.Worker_Profession_ID, b.Profession_Name, d.FirstDay, d.Fifth_Week_Days, d.Sixth_Week_Days
	
	select c.Department_Parent_Id as department_id, a.Worker_Section_ID as area_id, a.Worker_Profession_ID as Profession_Code, a.Count_Workers, a.Count_Workers as Count_Workers_Calculated, a.Fifth_Week_Days as FifthDays, a.Sixth_Week_Days as SixthDays, a.Fifth_Week_Days as WorkingDays, a.FirstDay as CalculationDate, b.Required_Time, a.StartWorkingTime, a.StartWorkingTime as WorkingTime, convert(float,0.0) as OverWorkingPerMonth, 0 as WorkingSaturdays, 0 as StaffNeed, 0 as WorkersDiff, ROW_NUMBER() over(order by c.Department_Parent_Id, a.Worker_Section_ID, a.Worker_Profession_ID) as Calc_Id
	into #ForCalculation
	from #Fond_WT a
	left join WorkingDemand b on a.Worker_Section_ID = b.Department_Section_Id and a.Worker_Profession_ID = b.Profession_Id and a.FirstDay = b.Demand_Date
	join Departments_Sections c on a.Worker_Section_ID = c.Department_Id

	update #ForCalculation
	set StaffNeed = (WorkingTime - Required_Time)/(Count_Workers_Calculated*WorkingDays)

	delete from WorkersMovements
	
	if(@param_overtime = 1)
	begin
		select Calc_ID, a.WorkingDays,
		case 
		when OverYPerWorker <= 120 and  OverDPerWorker <= 2 then OverDPerWorker
		when OverYPerWorker <= 120 and OverDPerWorker > 2 then 2.0
		when OverYPerWorker > 120 then 120.0/WorkingDaysSummary
		end as OverWorkPerDay
		into #DistrOverWork
		from (	select a.*, b.OverWorkYear/a.Count_Workers_Calculated OverYPerWorker, (-a.WorkingTime + Required_Time)/(a.Count_Workers_Calculated*a.WorkingDays) as OverDPerWorker, WorkingDaysSummary
				from #ForCalculation a 
				join (	select department_id, area_id, Profession_Code, year(CalculationDate) as Year, sum(Required_Time - WorkingTime) as OverWorkYear, sum(WorkingDays) as WorkingDaysSummary
				from #ForCalculation
				where WorkingTime<Required_Time
				group by department_id, area_id, Profession_Code, year(CalculationDate)) b on a.department_id = b.department_id and a.area_id = b.area_id and year(a.CalculationDate) = b.Year and a.Profession_Code = b.Profession_Code
				where a.Required_Time > a.WorkingTime) a

		;with mytable as(
		select a.*, convert(float,ceiling(b.OverWorkPerDay * b.WorkingDays)) PerMonth
		from #ForCalculation a
		join #DistrOverWork b on a.Calc_Id = b.Calc_Id)
		update mytable
		set OverWorkingPerMonth = PerMonth, WorkingTime = WorkingTime + PerMonth
	end;

	if(@param_work_sat = 1)
	begin
		update #ForCalculation
		set WorkingTime = Required_Time, WorkingDays = Required_Time/(8*Count_Workers_Calculated)
		where Required_Time > Count_Workers_Calculated*8.0*FifthDays 
	end;
	
	select *, ROW_NUMBER() over(order by Department_iD, area_id, profession_code, calculationdate) AS id
	into #WorkersProficit
	from #ForCalculation
	where StaffNeed > 0

	select *, ROW_NUMBER() over(order by Department_iD, area_id, profession_code, calculationdate) AS id
	into #WorkersDeficit
	from #ForCalculation
	where StaffNeed < 0
	
	declare @iter int = 1

	if(@param_area_move = 1)
	begin
		while @iter >0
		begin
			set @iter = (	select count(a.Calc_Id)
									from (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed,ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed desc) as ri1
											from #WorkersProficit a) a
											join (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed, ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed asc ) as ri2
													from #WorkersDeficit a) b on a.department_id = b.department_id and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
											where ri1 =1 and ri2 = 1 and a.StaffNeed > -b.StaffNeed)
	
			insert into WorkersMovements
			select a.Calc_Id,b.Calc_Id, 
			case when a.StaffNeed > -b.StaffNeed then -b.StaffNeed
			else a.StaffNeed end as WorkersToMove
			from (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed,ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed desc) as ri1
					from #WorkersProficit a) a
			join (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed, ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed asc ) as ri2
					from #WorkersDeficit a) b on a.department_id = b.department_id and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			where ri1 =1 and ri2 = 1 and a.StaffNeed > -b.StaffNeed

			select a.Calc_Id as id_from,b.Calc_Id as id_to,a.CalculationDate,a.department_id, a.area_id as area_from, b.area_id as area_to, a.Profession_Code, a.StaffNeed as workers_from, b.StaffNeed as workers_to, 
			case when a.StaffNeed > -b.StaffNeed then -b.StaffNeed
			else a.StaffNeed end as WorkersToMove
			into #WorkersDiff
			from (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed,ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed desc) as ri1
					from #WorkersProficit a) a
			join (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed, ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed asc ) as ri2
					from #WorkersDeficit a) b on a.department_id = b.department_id and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			where ri1 =1 and ri2 = 1 and a.StaffNeed > -b.StaffNeed
	
			;with updateProficit as(
				select	
						a.WorkingTime, 
						a.WorkingTime- b.WorkersToMove*8*a.FifthDays as NewWorkingTime, 
						a.StaffNeed,a.StaffNeed - b.WorkersToMove as NewStaffNeed, 
						a.Count_Workers_Calculated, 
						a.Count_Workers_Calculated-b.WorkersToMove as NewCountWorkers
				from #WorkersProficit a
				join #WorkersDiff b on a.department_id = b.department_id and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			)
			update updateProficit
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated =NewCountWorkers
	
			;with updateDeficit as(
				select	a.WorkingTime, 
						a.WorkingTime+ b.WorkersToMove*8*a.WorkingDays as NewWorkingTime, 
						a.StaffNeed,
						a.StaffNeed + b.WorkersToMove as NewStaffNeed, 
						a.Count_Workers_Calculated, 
						a.Count_Workers_Calculated+b.WorkersToMove as NewCountWorkers
				from #WorkersDeficit a
				join #WorkersDiff b on a.department_id = b.department_id and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			)
			update updateDeficit
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated =NewCountWorkers
	
			;with updateCalculation as(
				select a.Count_Workers_Calculated, a.WorkingTime, a.Count_Workers_Calculated + b.WorkersToMove as NewCountWorkers, 
				a.WorkingTime + b.WorkersToMove*a.WorkingDays*8 as NewWorkingTime, a.StaffNeed, a.StaffNeed + b.WorkersToMove as NewStaffNeed
				from #ForCalculation a
				join #WorkersDiff b on a.Calc_Id = b.id_to
			)
			update updateCalculation
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated = NewCountWorkers

			;with updateCalculation as(
				select a.Count_Workers_Calculated, a.WorkingTime, a.Count_Workers_Calculated - b.WorkersToMove as NewCountWorkers, 
				a.WorkingTime - b.WorkersToMove*a.WorkingDays*8  as NewWorkingTime, a.StaffNeed, a.StaffNeed as NewStaffNeed
				from #ForCalculation a
				join #WorkersDiff b on a.Calc_Id = b.id_from
			)
			update updateCalculation
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated = NewCountWorkers
			drop table #WorkersDiff
			delete from #WorkersDeficit
			where StaffNeed = 0
			delete from #WorkersProficit
			where StaffNeed = 0
		end;
	end;

	if(@param_department_move = 1)
	begin
		set @iter = 1
		while @iter >0
		begin
			set @iter = (	select count(a.Calc_Id)
									from (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed,ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed desc) as ri1
											from #WorkersProficit a) a
											join (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed, ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed asc ) as ri2
													from #WorkersDeficit a) b on a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
											where ri1 =1 and ri2 = 1 and a.StaffNeed > -b.StaffNeed)
		
			insert into WorkersMovements
			select a.Calc_Id,b.Calc_Id, 
			case when a.StaffNeed > -b.StaffNeed then -b.StaffNeed
			else a.StaffNeed end as WorkersToMove
			from (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed,ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed desc) as ri1
					from #WorkersProficit a) a
			join (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed, ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed asc ) as ri2
					from #WorkersDeficit a) b on a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			where ri1 =1 and ri2 = 1 and a.StaffNeed > -b.StaffNeed

			select a.Calc_Id as id_from,b.Calc_Id as id_to,a.CalculationDate,a.department_id as department_from, b.department_id as department_to, a.area_id as area_from, b.area_id as area_to, a.Profession_Code, a.StaffNeed as workers_from, b.StaffNeed as workers_to, 
			case when a.StaffNeed > -b.StaffNeed then -b.StaffNeed
			else a.StaffNeed end as WorkersToMove
			into #WorkersDiffDep
			from (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed,ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed desc) as ri1
					from #WorkersProficit a) a
			join (	select a.Calc_Id, a.department_id,  a.Profession_Code, a.CalculationDate, a.area_id, a.StaffNeed, ROW_NUMBER() over(partition by a.calculationDate, a.department_id, a.profession_code order by a.staffneed asc ) as ri2
					from #WorkersDeficit a) b on a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			where ri1 =1 and ri2 = 1 and a.StaffNeed > -b.StaffNeed
	
			;with updateProficit as(
				select	
						a.WorkingTime, 
						a.WorkingTime- b.WorkersToMove*8*a.FifthDays as NewWorkingTime, 
						a.StaffNeed,a.StaffNeed - b.WorkersToMove as NewStaffNeed, 
						a.Count_Workers_Calculated, 
						a.Count_Workers_Calculated-b.WorkersToMove as NewCountWorkers
				from #WorkersProficit a
				join #WorkersDiffDep b on a.department_id = b.department_from and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			)
			update updateProficit
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated =NewCountWorkers
	
			;with updateDeficit as(
				select	a.WorkingTime, 
						a.WorkingTime+ b.WorkersToMove*8*a.WorkingDays as NewWorkingTime, 
						a.StaffNeed,
						a.StaffNeed + b.WorkersToMove as NewStaffNeed, 
						a.Count_Workers_Calculated, 
						a.Count_Workers_Calculated+b.WorkersToMove as NewCountWorkers
				from #WorkersDeficit a
				join #WorkersDiffDep b on a.department_id = b.department_to and a.Profession_Code = b.Profession_Code and a.CalculationDate = b.CalculationDate
			)
			update updateDeficit
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated =NewCountWorkers
	
			;with updateCalculation as(
				select a.Count_Workers_Calculated, a.WorkingTime, a.Count_Workers_Calculated + b.WorkersToMove as NewCountWorkers, 
				a.WorkingTime + b.WorkersToMove*a.WorkingDays*8 as NewWorkingTime, a.StaffNeed, a.StaffNeed + b.WorkersToMove as NewStaffNeed
				from #ForCalculation a
				join #WorkersDiffDep b on a.Calc_Id = b.id_to
			)
			update updateCalculation
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated = NewCountWorkers

			;with updateCalculation as(
				select a.Count_Workers_Calculated, a.WorkingTime, a.Count_Workers_Calculated - b.WorkersToMove as NewCountWorkers, 
				a.WorkingTime - b.WorkersToMove*a.WorkingDays*8  as NewWorkingTime, a.StaffNeed, a.StaffNeed as NewStaffNeed
				from #ForCalculation a
				join #WorkersDiffDep b on a.Calc_Id = b.id_from
			)
			update updateCalculation
			set WorkingTime = NewWorkingTime, StaffNeed = NewStaffNeed, Count_Workers_Calculated = NewCountWorkers

			drop table #WorkersDiffDep
	
			delete from #WorkersDeficit
			where StaffNeed = 0

			delete from #WorkersProficit
			where StaffNeed = 0	
		end;

	end;

	select top 0 a.Department_Id, c.Department_Parent_Name as Department_Name,a.Area_Id, c.Department_Name as Area_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
	into #WorkingTable
	from #ForCalculation a
	join Departments_Sections c on a.area_id = c.Department_Id
	join Professions d on a.Profession_Code = d.Profession_Code
	where a.CalculationDate between @OpenDate and @CloseDate

	if(@department = -1 and @profession = -1)
	begin
		insert into #WorkingTable
		select a.Department_Id, c.Department_Parent_Name,a.Area_Id, c.Department_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
		from #ForCalculation a
		join Departments_Sections c on a.area_id = c.Department_Id
		join Professions d on a.Profession_Code = d.Profession_ID
		where a.CalculationDate between @OpenDate and @CloseDate
	end;
	else if(@department = -1 and @profession <> -1)
	begin
		insert into #WorkingTable
		select a.Department_Id, c.Department_Parent_Name,a.Area_Id, c.Department_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
		from #ForCalculation a
		join Departments_Sections c on a.area_id = c.Department_Id
		join Professions d on a.Profession_Code = d.Profession_Id
		where a.CalculationDate between @OpenDate and @CloseDate and a.Profession_Code = @profession
	end
	else if(@department <> -1 and @area =-1 and @profession <> -1)
	begin
		insert into #WorkingTable
		select a.Department_Id, c.Department_Parent_Name,a.Area_Id, c.Department_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
		from #ForCalculation a
		join Departments_Sections c on a.area_id = c.Department_Id
		join Professions d on a.Profession_Code = d.Profession_Id
		where a.CalculationDate between @OpenDate and @CloseDate and a.department_id= @department and a.Profession_Code = @profession
	end
	else if(@department <> -1 and @area <>-1 and @profession =-1)
	begin
		insert into #WorkingTable
		select a.Department_Id, c.Department_Parent_Name,a.Area_Id, c.Department_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
		from #ForCalculation a
		join Departments_Sections c on a.area_id = c.Department_Id
		join Professions d on a.Profession_Code = d.Profession_Id
		where a.CalculationDate between @OpenDate and @CloseDate and a.department_id = @department and a.area_id = @area

	end
	else if(@department <> -1 and @area <>-1 and @profession <> -1)
	begin
		insert into #WorkingTable
		select a.Department_Id, c.Department_Parent_Name,a.Area_Id, c.Department_Name as Area_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
		from #ForCalculation a
		join Departments_Sections c on a.area_id = c.Department_Id
		join Professions d on a.Profession_Code = d.Profession_Id
		where a.CalculationDate between @OpenDate and @CloseDate and a.department_id = @department and a.area_id = @area and a.Profession_Code = @profession
	end
	else if(@department <> -1 and @area =-1 and @profession = -1)
	begin
		insert into #WorkingTable
		select a.Department_Id, c.Department_Parent_Name,a.Area_Id, c.Department_Name as Area_Name, a.Profession_Code,d.Profession_Name, a.CalculationDate, a.WorkingTime, a.StartWorkingTime, a.Required_Time, ROW_NUMBER() over(partition by a.Department_Id, a.Area_Id, a.Profession_Code order by a.Department_Id, a.Area_Id, a.Profession_Code, a.CalculationDate) as ri1
		from #ForCalculation a
		join Departments_Sections c on a.area_id = c.Department_Id
		join Professions d on a.Profession_Code = d.Profession_Id
		where a.CalculationDate between @OpenDate and @CloseDate and a.department_id = @department 
	end
	
	
	select case 
	when month(CalculationDate) =  1 then concat('Январь ',year(CalculationDate))
	when month(CalculationDate) =  2 then concat('Февраль ',year(CalculationDate)) 
	when month(CalculationDate) =  3 then concat('Март ',year(CalculationDate)) 
	when month(CalculationDate) =  4 then concat('Апрель ',year(CalculationDate)) 
	when month(CalculationDate) =  5 then concat('Май ',year(CalculationDate)) 
	when month(CalculationDate) =  6 then concat('Июнь ',year(CalculationDate)) 
	when month(CalculationDate) =  7 then concat('Июль ',year(CalculationDate)) 
	when month(CalculationDate) =  8 then concat('Август ',year(CalculationDate)) 
	when month(CalculationDate) =  9 then concat('Сентябрь ',year(CalculationDate)) 
	when month(CalculationDate) =  10 then concat('Октябрь ',year(CalculationDate)) 
	when month(CalculationDate) =  11 then concat('Ноябрь ',year(CalculationDate)) 
	when month(CalculationDate) =  12 then concat('Декабрь ',year(CalculationDate)) 
	end as Date, 
	ROW_NUMBER() over(order by CalculationDate) as Id
	into #Months
	from (select distinct CalculationDate from #WorkingTable) a
	order by CalculationDate

	declare @index_i int = 1, @index_max int = (select count(id) from #Months), @str_reqt varchar(max) = '', @str_workt varchar(max), @str_sworkt varchar(max), @str_index varchar(max) = '', 
	@str_head varchar(max) = '',@str_dates varchar(max) = '', @current_date varchar(max),	@query nvarchar(max) = ''

	while @index_i <= @index_max 
	begin
		set @current_date = (select top 1 Date from #Months where Id = @index_i)
		set @str_reqt = concat(@str_reqt,'round(sum([',@index_i,']),1) as RQT',@index_i,', ')
		set @str_sworkt = concat(@str_workt,'sum([',@index_i,']) as SWT',@index_i,', ')
		set @str_workt = concat(@str_sworkt,'sum([',@index_i,']) as WT',@index_i,', ')
		set @str_head = concat(@str_head,' b.SWT',@index_i,', c.WT',@index_i,', a.RQT',@index_i,',''', @current_date,''' as ''',@current_date,''', ')
		set @str_index = concat(@str_index, '[',@index_i,'],')
	set @index_i +=1
	end;

	set @str_reqt = SUBSTRING(@str_reqt, 1, len(@str_reqt)-1)
	set @str_workt = SUBSTRING(@str_workt, 1, len(@str_workt)-1)
	set @str_sworkt = SUBSTRING(@str_sworkt, 1, len(@str_sworkt)-1)
	set @str_head = SUBSTRING(@str_head, 1, len(@str_head)-1)
	set @str_index = substring(@str_index,1,len(@str_index)-1) 

	set @query = concat('select a.Department_Id, a.Area_Id, a.Profession_Code, a.Department_Name, a.Area_Name, a.Profession_Name,',@str_head,char(10),
						'from (select Department_Id, Department_Name, Area_Id, Area_Name, Profession_Code, Profession_Name, ', @str_reqt,char(10),
								'from  #WorkingTable as a pivot (sum(Required_Time) for ri1 in (', @str_index,')) as pvt', char(10),
								'group by Department_Id, Department_Name, Area_Id, Area_Name, Profession_Code, Profession_Name) as a', char(10),
						'join (select Department_Id, Area_Id, Profession_Code, ', @str_sworkt,char(10),
								'from  #WorkingTable as a pivot (sum(StartWorkingTime) for ri1 in (', @str_index,')) as pvt', char(10),
								'group by  Department_Id, Area_Id, Profession_Code) as b on a.area_id = b.area_id and a.profession_code= b.profession_code', char(10),
						'join (select Department_Id, Area_Id, Profession_Code, ', @str_workt,char(10),
								'from  #WorkingTable as a pivot (sum(WorkingTime) for ri1 in (', @str_index,')) as pvt', char(10),
								'group by  Department_Id, Area_Id, Profession_Code) as c on a.area_id = c.area_id and a.profession_code= c.profession_code', char(10))
	exec sp_executesql @Query
	
	select *
	into CalculationInformation
	from #ForCalculation
end;
go

